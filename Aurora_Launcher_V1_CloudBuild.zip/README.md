# Aurora Launcher V1

Android launcher prototype inspired by modern translucent mobile UI.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android 8.0+ device/emulator.
4. Press Home and select **Aurora Launcher** as the default Home app.

## Included
- Home screen
- App shortcuts
- Search overlay
- Swipe-up Control Center
- Wi-Fi/Bluetooth/Flashlight/Dark Mode UI toggles
- Modern translucent/rounded visual style
- Clock/date
- Dock

Note: the first version provides the launcher UI and shortcut actions. System-level controls such as actual Wi-Fi/Bluetooth/flashlight state require additional Android APIs/permissions and device-specific handling.
