package com.example.ios26launcher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

data class AppShortcut(val name: String, val icon: ImageVector, val action: () -> Unit)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { AuroraLauncher() }
    }
}

@Composable
fun AuroraLauncher() {
    val context = LocalContext.current
    var controlCenter by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(false) }
    var flashlight by remember { mutableStateOf(false) }
    var wifi by remember { mutableStateOf(true) }
    var bluetooth by remember { mutableStateOf(true) }

    val apps = listOf(
        AppShortcut("Phone", Icons.Default.Call) { launch(context, Intent(Intent.ACTION_DIAL)) },
        AppShortcut("Messages", Icons.Default.Message) { launch(context, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)) },
        AppShortcut("Camera", Icons.Default.CameraAlt) { launch(context, Intent("android.media.action.IMAGE_CAPTURE")) },
        AppShortcut("Settings", Icons.Default.Settings) { launch(context, Intent(Settings.ACTION_SETTINGS)) },
        AppShortcut("Browser", Icons.Default.Language) { launch(context, Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))) },
        AppShortcut("Gallery", Icons.Default.Photo) { launch(context, Intent(Intent.ACTION_VIEW).setType("image/*")) },
        AppShortcut("Clock", Icons.Default.Schedule) { launch(context, Intent(Settings.ACTION_DATE_SETTINGS)) },
        AppShortcut("Files", Icons.Default.Folder) { launch(context, Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)) }
    )

    Box(
        Modifier.fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1D2945), Color(0xFF657FA8), Color(0xFFB8C9D8))
                )
            )
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onVerticalDrag = { _, drag -> if (drag < -20) controlCenter = true }
                )
            }
    ) {
        Column(
            Modifier.fillMaxSize().padding(top = 42.dp, start = 18.dp, end = 18.dp, bottom = 24.dp)
        ) {
            var time by remember { mutableStateOf("") }
            LaunchedEffect(Unit) {
                while (true) {
                    time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                    delay(1000)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text(time, fontSize = 30.sp, fontWeight = FontWeight.Light, color = Color.White)
                    Text(
                        SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()),
                        color = Color.White.copy(alpha = .85f),
                        fontSize = 14.sp
                    )
                }
                IconButton(onClick = { search = true }) {
                    Icon(Icons.Default.Search, "Search", tint = Color.White)
                }
            }

            Spacer(Modifier.height(28.dp))

            Surface(
                modifier = Modifier.fillMaxWidth().height(58.dp).clickable { search = true },
                shape = RoundedCornerShape(28.dp),
                color = Color.White.copy(alpha = .22f)
            ) {
                Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, null, tint = Color.White.copy(alpha = .85f))
                    Spacer(Modifier.width(10.dp))
                    Text("Search apps", color = Color.White.copy(alpha = .85f))
                }
            }

            Spacer(Modifier.height(22.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(apps) { app ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(18.dp)).clickable { app.action() },
                            shape = RoundedCornerShape(18.dp),
                            color = Color.White.copy(alpha = .88f),
                            shadowElevation = 8.dp
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(app.icon, app.name, tint = Color(0xFF27344D), modifier = Modifier.size(30.dp))
                            }
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(app.name, color = Color.White, fontSize = 12.sp)
                    }
                }
            }

            Surface(
                Modifier.fillMaxWidth().height(82.dp),
                RoundedCornerShape(30.dp),
                color = Color.White.copy(alpha = .22f)
            ) {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DockButton(Icons.Default.Call) { launch(context, Intent(Intent.ACTION_DIAL)) }
                    DockButton(Icons.Default.Message) { launch(context, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)) }
                    DockButton(Icons.Default.CameraAlt) { launch(context, Intent("android.media.action.IMAGE_CAPTURE")) }
                    DockButton(Icons.Default.Settings) { launch(context, Intent(Settings.ACTION_SETTINGS)) }
                }
            }
        }

        AnimatedVisibility(controlCenter, Modifier.align(Alignment.TopCenter)) {
            ControlCenter(
                wifi = wifi, bluetooth = bluetooth, flashlight = flashlight, dark = dark,
                onWifi = { wifi = !wifi }, onBluetooth = { bluetooth = !bluetooth },
                onFlashlight = { flashlight = !flashlight }, onDark = { dark = !dark },
                onClose = { controlCenter = false }
            )
        }

        if (search) {
            SearchOverlay(apps = apps, onClose = { search = false })
        }
    }
}

@Composable
fun DockButton(icon: ImageVector, onClick: () -> Unit) {
    Surface(
        Modifier.size(54.dp).clickable { onClick() },
        RoundedCornerShape(17.dp), color = Color.White.copy(alpha = .9f)
    ) {
        Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color(0xFF27344D)) }
    }
}

@Composable
fun ControlCenter(
    wifi: Boolean, bluetooth: Boolean, flashlight: Boolean, dark: Boolean,
    onWifi: () -> Unit, onBluetooth: () -> Unit, onFlashlight: () -> Unit,
    onDark: () -> Unit, onClose: () -> Unit
) {
    Surface(
        Modifier.fillMaxSize(),
        color = Color.Black.copy(alpha = .48f)
    ) {
        Column(Modifier.fillMaxSize().padding(24.dp).padding(top = 36.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Control Center", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
            }
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Toggle("Wi-Fi", Icons.Default.Wifi, wifi, onWifi)
                Toggle("Bluetooth", Icons.Default.Bluetooth, bluetooth, onBluetooth)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Toggle("Flashlight", Icons.Default.FlashOn, flashlight, onFlashlight)
                Toggle("Dark Mode", Icons.Default.DarkMode, dark, onDark)
            }
            Spacer(Modifier.height(18.dp))
            Surface(Modifier.fillMaxWidth().height(130.dp), RoundedCornerShape(26.dp), Color.White.copy(alpha=.18f)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Display", color = Color.White, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { .72f }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
fun Toggle(label: String, icon: ImageVector, active: Boolean, onClick: () -> Unit) {
    val alpha by animateFloatAsState(if (active) 1f else .45f, label = "toggle")
    Surface(
        Modifier.size(145.dp, 105.dp).clickable { onClick() }.alpha(alpha),
        RoundedCornerShape(24.dp), Color.White.copy(alpha = .20f)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Surface(Modifier.size(42.dp), CircleShape, Color.White.copy(alpha=.9f)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color(0xFF27344D)) }
            }
            Text(label, color = Color.White)
        }
    }
}

@Composable
fun SearchOverlay(apps: List<AppShortcut>, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    Surface(Modifier.fillMaxSize(), color = Color(0xFF101522).copy(alpha=.96f)) {
        Column(Modifier.padding(24.dp).padding(top = 38.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Search apps") },
                    singleLine = true
                )
                TextButton(onClick = onClose) { Text("Done") }
            }
            Spacer(Modifier.height(20.dp))
            apps.filter { it.name.contains(query, ignoreCase = true) }.forEach { app ->
                Row(
                    Modifier.fillMaxWidth().clickable { app.action() }.padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(app.icon, null, tint = Color.White, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(app.name, color = Color.White, fontSize = 17.sp)
                }
            }
        }
    }
}

private fun launch(context: android.content.Context, intent: Intent) {
    try { context.startActivity(intent) } catch (_: Exception) {}
}
